// src/app/features/finance/services/finance.service.ts
import { Injectable } from '@angular/core';
import { Observable, from, of, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import {
  GivingTransaction,
  GivingCategory,
  Pledge,
  PaymentMethod,
  CategoryGiver,
  CategoryGivingStat,
  CategorySummary,
  BulkGivingRecord,
  CategoryExpense,
} from '../../../models/giving.model';
import { SupabaseService } from '../../../core/services/supabase';
import { AuthService } from '../../../core/services/auth';

export interface GivingStatistics {
  total_giving: number;
  total_tithes: number;
  total_offerings: number;
  total_transactions: number;
  avg_giving: number;
  highest_giving: number;
}

export interface CombinedGivingStats {
  individual_total: number;
  individual_tithes: number;
  individual_offerings: number;
  individual_transactions: number;
  individual_avg: number;
  individual_highest: number;
  bulk_total: number;
  bulk_records_count: number;
  combined_total: number;
  total_expenses: number;
  net_total: number;
}

export interface TopGiver {
  member_id: string;
  member_name: string;
  total_amount: number;
  transaction_count: number;
}

export interface GivingTrend {
  month: string;
  total_amount: number;
  transaction_count: number;
}

@Injectable({ providedIn: 'root' })
export class FinanceService {
  constructor(
    private supabase: SupabaseService,
    private authService: AuthService,
  ) {}

  private getChurchId(): string {
    const churchId = this.authService.getChurchId();
    if (!churchId) throw new Error('Church ID not found. Please log in again.');
    return churchId;
  }

  private getCurrentUserId(): string {
    const userId = this.authService.getUserId();
    if (!userId) throw new Error('User ID not found. Please log in again.');
    return userId;
  }

  private getBranchId(): string | undefined {
    return this.authService.getBranchId();
  }

  private isBranchPastor(): boolean {
    return this.authService.isBranchPastor();
  }

  /**
   * Branch autonomy is OFF by default. Pledge scoping/stamping applies only to
   * branch-scoped staff of churches that have the 'branch_autonomy' switch ON,
   * so nothing changes for any other church (or before the DB migration is run).
   */
  private isAutonomyScoped(): boolean {
    return this.authService.isBranchPastor() && this.authService.hasChurchFeature('branch_autonomy');
  }

  // ==================== GIVING CATEGORIES ====================

  getGivingCategories(): Observable<GivingCategory[]> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client
        .from('giving_categories')
        .select('*')
        .eq('church_id', churchId)
        .eq('is_active', true)
        .order('name', { ascending: true }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return (data || []) as GivingCategory[];
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  createGivingCategory(categoryData: {
    name: string;
    description?: string;
  }): Observable<GivingCategory> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client
        .from('giving_categories')
        .insert({
          church_id: churchId,
          name: categoryData.name,
          description: categoryData.description,
          is_active: true,
        })
        .select()
        .single(),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data as GivingCategory;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  updateGivingCategory(
    categoryId: string,
    categoryData: { name?: string; description?: string },
  ): Observable<GivingCategory> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client
        .from('giving_categories')
        .update({
          name: categoryData.name,
          description: categoryData.description,
        })
        .eq('id', categoryId)
        .eq('church_id', churchId)
        .select()
        .single(),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data as GivingCategory;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  deleteGivingCategory(categoryId: string): Observable<void> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client
        .from('giving_categories')
        .update({ is_active: false })
        .eq('id', categoryId)
        .eq('church_id', churchId),
    ).pipe(
      map(({ error }) => {
        if (error) throw new Error(error.message);
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  // ==================== CATEGORY SUMMARY CARDS ====================

  getCategorySummary(
    fiscalYear?: number,
    startDate?: string,
    endDate?: string,
  ): Observable<CategorySummary[]> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client.rpc('get_category_summary', {
        church_uuid: churchId,
        p_fiscal_year: fiscalYear ?? null,
        p_start_date: startDate ?? null,
        p_end_date: endDate ?? null,
      }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return (data || []) as CategorySummary[];
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  getCombinedGivingStats(
    fiscalYear?: number,
  ): Observable<CombinedGivingStats | null> {
    const churchId = this.getChurchId();
    const year = fiscalYear || new Date().getFullYear();
    return from(
      this.supabase.client.rpc('get_combined_giving_stats', {
        church_uuid: churchId,
        fiscal_year: year,
      }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        if (Array.isArray(data) && data.length > 0)
          return data[0] as CombinedGivingStats;
        return data as CombinedGivingStats;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  // ==================== GIVING TRANSACTIONS ====================

  getGivingTransactions(
    page: number = 1,
    pageSize: number = 20,
    filters?: {
      startDate?: string;
      endDate?: string;
      categoryId?: string;
      memberId?: string;
      paymentMethod?: PaymentMethod | '';
    },
  ): Observable<{ data: any[]; count: number }> {
    return from(this.fetchGivingTransactions(page, pageSize, filters));
  }

  private async fetchGivingTransactions(
    page: number,
    pageSize: number,
    filters?: any,
  ): Promise<{ data: any[]; count: number }> {
    const churchId = this.getChurchId();
    const isBranchPastor = this.isBranchPastor();
    const branchId = this.getBranchId();
    const offset = (page - 1) * pageSize;

    let query = this.supabase.client
      .from('giving_transactions')
      .select(
        `*, category:giving_categories(id, name),
         member:members(id, first_name, last_name, member_number, photo_url)`,
        { count: 'exact' },
      )
      .eq('church_id', churchId);

    if (isBranchPastor && branchId) query = query.eq('branch_id', branchId);
    if (filters?.startDate)
      query = query.gte('transaction_date', filters.startDate);
    if (filters?.endDate)
      query = query.lte('transaction_date', filters.endDate);
    if (filters?.categoryId)
      query = query.eq('category_id', filters.categoryId);
    if (filters?.memberId) query = query.eq('member_id', filters.memberId);
    if (filters?.paymentMethod)
      query = query.eq('payment_method', filters.paymentMethod);
    // Only show completed Paystack transactions — hide pending/failed/abandoned.
    // Manual payments (cash, mobile_money manual etc.) have null payment_status
    // and are always shown. This mirrors what members see in their own history.
    query = query.or('payment_status.eq.completed,payment_status.is.null');

    const { data, error, count } = await query
      .order('transaction_date', { ascending: false })
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    if (error) throw new Error(error.message);
    return { data: data || [], count: count || 0 };
  }

  getGivingTransactionById(transactionId: string): Observable<any> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client
        .from('giving_transactions')
        .select(
          `*, category:giving_categories(id, name), member:members(id, first_name, last_name, member_number, photo_url)`,
        )
        .eq('id', transactionId)
        .eq('church_id', churchId)
        .single(),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  createGivingTransaction(transactionData: any): Observable<GivingTransaction> {
    const churchId = this.getChurchId();
    const currentUserId = this.getCurrentUserId();
    const branchId = this.getBranchId();
    const currentYear = new Date(
      transactionData.transaction_date,
    ).getFullYear();

    return from(
      this.supabase.client
        .from('giving_transactions')
        .insert({
          church_id: churchId,
          branch_id: branchId || null,
          member_id: transactionData.member_id || null,
          category_id: transactionData.category_id,
          amount: transactionData.amount,
          currency: transactionData.currency,
          payment_method: transactionData.payment_method,
          transaction_reference: transactionData.transaction_reference || null,
          transaction_date: transactionData.transaction_date,
          fiscal_year: currentYear,
          notes: transactionData.notes || null,
          recorded_by: currentUserId,
        })
        .select()
        .single(),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data as GivingTransaction;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  updateGivingTransaction(
    transactionId: string,
    transactionData: any,
  ): Observable<GivingTransaction> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client
        .from('giving_transactions')
        .update({
          member_id: transactionData.member_id,
          category_id: transactionData.category_id,
          amount: transactionData.amount,
          currency: transactionData.currency,
          payment_method: transactionData.payment_method,
          transaction_reference: transactionData.transaction_reference,
          transaction_date: transactionData.transaction_date,
          notes: transactionData.notes,
          updated_at: new Date().toISOString(),
        })
        .eq('id', transactionId)
        .eq('church_id', churchId)
        .select()
        .single(),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data as GivingTransaction;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  deleteGivingTransaction(transactionId: string): Observable<void> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client
        .from('giving_transactions')
        .delete()
        .eq('id', transactionId)
        .eq('church_id', churchId),
    ).pipe(
      map(({ error }) => {
        if (error) throw new Error(error.message);
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  // ==================== BULK GIVING RECORDS ====================

  getBulkGivingRecords(
    page: number = 1,
    pageSize: number = 20,
    filters?: { categoryId?: string; startDate?: string; endDate?: string },
  ): Observable<{ data: BulkGivingRecord[]; count: number }> {
    return from(this.fetchBulkGivingRecords(page, pageSize, filters));
  }

  private async fetchBulkGivingRecords(
    page: number,
    pageSize: number,
    filters?: any,
  ): Promise<{ data: BulkGivingRecord[]; count: number }> {
    const churchId = this.getChurchId();
    const offset = (page - 1) * pageSize;

    let query = this.supabase.client
      .from('bulk_giving_records')
      .select(`*, category:giving_categories(id, name)`, { count: 'exact' })
      .eq('church_id', churchId);

    if (filters?.categoryId)
      query = query.eq('category_id', filters.categoryId);
    if (filters?.startDate) query = query.gte('record_date', filters.startDate);
    if (filters?.endDate) query = query.lte('record_date', filters.endDate);

    const { data, error, count } = await query
      .order('record_date', { ascending: false })
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    if (error) throw new Error(error.message);
    return {
      data: (data || []).map((r: any) => ({
        ...r,
        category_name: r.category?.name,
      })),
      count: count || 0,
    };
  }

  createBulkGivingRecord(recordData: {
    category_id: string;
    total_amount: number;
    currency: string;
    payment_method: string;
    record_date: string;
    attendee_count?: number;
    description?: string;
    notes?: string;
  }): Observable<BulkGivingRecord> {
    const churchId = this.getChurchId();
    const currentUserId = this.getCurrentUserId();
    const branchId = this.getBranchId();

    return from(
      this.supabase.client
        .from('bulk_giving_records')
        .insert({
          church_id: churchId,
          branch_id: branchId || null,
          category_id: recordData.category_id,
          total_amount: recordData.total_amount,
          currency: recordData.currency,
          payment_method: recordData.payment_method,
          record_date: recordData.record_date,
          attendee_count: recordData.attendee_count || null,
          description: recordData.description || null,
          notes: recordData.notes || null,
          recorded_by: currentUserId,
        })
        .select()
        .single(),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data as BulkGivingRecord;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  updateBulkGivingRecord(
    recordId: string,
    recordData: Partial<BulkGivingRecord>,
  ): Observable<BulkGivingRecord> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client
        .from('bulk_giving_records')
        .update({
          category_id: recordData.category_id,
          total_amount: recordData.total_amount,
          currency: recordData.currency,
          payment_method: recordData.payment_method,
          record_date: recordData.record_date,
          attendee_count: recordData.attendee_count,
          description: recordData.description,
          notes: recordData.notes,
          updated_at: new Date().toISOString(),
        })
        .eq('id', recordId)
        .eq('church_id', churchId)
        .select()
        .single(),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data as BulkGivingRecord;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  deleteBulkGivingRecord(recordId: string): Observable<void> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client
        .from('bulk_giving_records')
        .delete()
        .eq('id', recordId)
        .eq('church_id', churchId),
    ).pipe(
      map(({ error }) => {
        if (error) throw new Error(error.message);
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  // ==================== CATEGORY EXPENSES ====================

  getCategoryExpenses(
    page: number = 1,
    pageSize: number = 20,
    filters?: { categoryId?: string; startDate?: string; endDate?: string },
  ): Observable<{ data: CategoryExpense[]; count: number }> {
    return from(this.fetchCategoryExpenses(page, pageSize, filters));
  }

  private async fetchCategoryExpenses(
    page: number,
    pageSize: number,
    filters?: any,
  ): Promise<{ data: CategoryExpense[]; count: number }> {
    const churchId = this.getChurchId();
    const offset = (page - 1) * pageSize;

    let query = this.supabase.client
      .from('category_expenses')
      .select(`*, category:giving_categories(id, name)`, { count: 'exact' })
      .eq('church_id', churchId);

    if (filters?.categoryId)
      query = query.eq('category_id', filters.categoryId);
    if (filters?.startDate)
      query = query.gte('expense_date', filters.startDate);
    if (filters?.endDate) query = query.lte('expense_date', filters.endDate);

    const { data, error, count } = await query
      .order('expense_date', { ascending: false })
      .order('created_at', { ascending: false })
      .range(offset, offset + pageSize - 1);

    if (error) throw new Error(error.message);
    return {
      data: (data || []).map((r: any) => ({
        ...r,
        category_name: r.category?.name,
      })),
      count: count || 0,
    };
  }

  createCategoryExpense(expenseData: {
    category_id: string;
    amount: number;
    currency: string;
    expense_date: string;
    title: string;
    description?: string;
    receipt_reference?: string;
    receipt_media_urls?: string[];
  }): Observable<CategoryExpense> {
    const churchId = this.getChurchId();
    const currentUserId = this.getCurrentUserId();
    const branchId = this.getBranchId();

    return from(
      this.supabase.client
        .from('category_expenses')
        .insert({
          church_id: churchId,
          branch_id: branchId || null,
          category_id: expenseData.category_id,
          amount: expenseData.amount,
          currency: expenseData.currency,
          expense_date: expenseData.expense_date,
          title: expenseData.title,
          description: expenseData.description || null,
          receipt_reference: expenseData.receipt_reference || null,
          receipt_media_urls: expenseData.receipt_media_urls || [],
          recorded_by: currentUserId,
        })
        .select()
        .single(),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data as CategoryExpense;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  updateCategoryExpense(
    expenseId: string,
    expenseData: Partial<CategoryExpense>,
  ): Observable<CategoryExpense> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client
        .from('category_expenses')
        .update({
          category_id: expenseData.category_id,
          amount: expenseData.amount,
          currency: expenseData.currency,
          expense_date: expenseData.expense_date,
          title: expenseData.title,
          description: expenseData.description,
          receipt_reference: expenseData.receipt_reference,
          receipt_media_urls: expenseData.receipt_media_urls,
          updated_at: new Date().toISOString(),
        })
        .eq('id', expenseId)
        .eq('church_id', churchId)
        .select()
        .single(),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data as CategoryExpense;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  deleteCategoryExpense(expenseId: string): Observable<void> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client
        .from('category_expenses')
        .delete()
        .eq('id', expenseId)
        .eq('church_id', churchId),
    ).pipe(
      map(({ error }) => {
        if (error) throw new Error(error.message);
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  // ==================== PLEDGES ====================

  getPledges(
    page: number = 1,
    pageSize: number = 20,
    filters?: { memberId?: string; categoryId?: string; isFulfilled?: boolean },
  ): Observable<{ data: any[]; count: number }> {
    return from(this.fetchPledges(page, pageSize, filters));
  }

  private async fetchPledges(
    page: number,
    pageSize: number,
    filters?: any,
  ): Promise<{ data: any[]; count: number }> {
    const churchId = this.getChurchId();
    const offset = (page - 1) * pageSize;

    let query = this.supabase.client
      .from('pledges')
      .select(
        `*, category:giving_categories(id, name), member:members(id, first_name, last_name, member_number, photo_url)`,
        { count: 'exact' },
      )
      .eq('church_id', churchId);

    // Branch-scoped staff only see their own branch's pledges (branch autonomy ON)
    const scopedBranchId = this.getBranchId();
    if (this.isAutonomyScoped() && scopedBranchId) {
      query = query.eq('branch_id', scopedBranchId);
    }

    if (filters?.memberId) query = query.eq('member_id', filters.memberId);
    if (filters?.categoryId)
      query = query.eq('category_id', filters.categoryId);
    if (filters?.isFulfilled !== undefined)
      query = query.eq('is_fulfilled', filters.isFulfilled);

    const { data, error, count } = await query
      .order('pledge_date', { ascending: false })
      .range(offset, offset + pageSize - 1);
    if (error) throw new Error(error.message);
    return { data: data || [], count: count || 0 };
  }

  getPledgeById(pledgeId: string): Observable<any> {
    const churchId = this.getChurchId();
    let pledgeQuery = this.supabase.client
      .from('pledges')
      .select(
        `*, category:giving_categories(id, name), member:members(id, first_name, last_name, member_number, photo_url, phone_primary)`,
      )
      .eq('id', pledgeId)
      .eq('church_id', churchId);

    // Branch-scoped staff cannot open another branch's pledge (branch autonomy ON)
    const scopedBranchId = this.getBranchId();
    if (this.isAutonomyScoped() && scopedBranchId) {
      pledgeQuery = pledgeQuery.eq('branch_id', scopedBranchId);
    }

    return from(pledgeQuery.single()).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  createPledge(pledgeData: any): Observable<Pledge> {
    const churchId = this.getChurchId();
    const insertData: any = {
      church_id: churchId,
      category_id: pledgeData.category_id || null,
      pledge_amount: pledgeData.pledge_amount,
      amount_paid: 0,
      currency: pledgeData.currency,
      pledge_date: pledgeData.pledge_date,
      due_date: pledgeData.due_date || null,
      is_fulfilled: false,
      notes: pledgeData.notes || null,
    };
    // Stamp the branch on pledges recorded by branch-scoped staff (branch autonomy ON)
    const stampBranchId = this.getBranchId();
    if (this.isAutonomyScoped() && stampBranchId) {
      insertData.branch_id = stampBranchId;
    }
    if (pledgeData.member_id) {
      insertData.member_id = pledgeData.member_id;
    } else {
      insertData.visitor_first_name = pledgeData.visitor_first_name;
      insertData.visitor_last_name = pledgeData.visitor_last_name;
      insertData.visitor_phone = pledgeData.visitor_phone || null;
      insertData.visitor_email = pledgeData.visitor_email || null;
    }
    return from(
      this.supabase.client.from('pledges').insert(insertData).select().single(),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data as Pledge;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  updatePledge(pledgeId: string, pledgeData: any): Observable<Pledge> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client
        .from('pledges')
        .update({
          pledge_amount: pledgeData.pledge_amount,
          amount_paid: pledgeData.amount_paid,
          currency: pledgeData.currency,
          pledge_date: pledgeData.pledge_date,
          due_date: pledgeData.due_date,
          is_fulfilled: pledgeData.is_fulfilled,
          notes: pledgeData.notes,
          updated_at: new Date().toISOString(),
        })
        .eq('id', pledgeId)
        .eq('church_id', churchId)
        .select()
        .single(),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data as Pledge;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  deletePledge(pledgeId: string): Observable<void> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client
        .from('pledges')
        .delete()
        .eq('id', pledgeId)
        .eq('church_id', churchId),
    ).pipe(
      map(({ error }) => {
        if (error) throw new Error(error.message);
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  // ==================== PLEDGE PAYMENTS ====================

  getPledgePayments(pledgeId: string): Observable<any[]> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client
        .from('pledge_payments')
        .select('*')
        .eq('pledge_id', pledgeId)
        .eq('church_id', churchId)
        .order('payment_date', { ascending: false }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data || [];
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  recordPledgePayment(pledgeId: string, paymentData: any): Observable<any> {
    return from(this.processPledgePayment(pledgeId, paymentData));
  }

  private async processPledgePayment(
    pledgeId: string,
    paymentData: any,
  ): Promise<any> {
    const churchId = this.getChurchId();
    const currentUserId = this.getCurrentUserId();

    const { data: pledge, error: fetchError } = await this.supabase.client
      .from('pledges')
      .select('*')
      .eq('id', pledgeId)
      .eq('church_id', churchId)
      .single();
    if (fetchError) throw new Error(fetchError.message);
    if (!pledge) throw new Error('Pledge not found');

    const remainingBalance = pledge.pledge_amount - pledge.amount_paid;
    if (paymentData.amount > remainingBalance)
      throw new Error(
        `Payment amount cannot exceed remaining balance of ${remainingBalance}`,
      );

    const { data: payment, error: paymentError } = await this.supabase.client
      .from('pledge_payments')
      .insert({
        pledge_id: pledgeId,
        church_id: churchId,
        amount: paymentData.amount,
        currency: paymentData.currency,
        payment_date: paymentData.payment_date,
        payment_method: paymentData.payment_method,
        transaction_reference: paymentData.transaction_reference || null,
        notes: paymentData.notes || null,
        recorded_by: currentUserId,
        // A payment belongs to the same branch as its pledge (only sent when set)
        ...(pledge.branch_id ? { branch_id: pledge.branch_id } : {}),
      })
      .select()
      .single();
    if (paymentError) throw new Error(paymentError.message);

    const newAmountPaid = pledge.amount_paid + paymentData.amount;
    const isFulfilled = newAmountPaid >= pledge.pledge_amount;

    const { data: updatedPledge, error: updateError } =
      await this.supabase.client
        .from('pledges')
        .update({
          amount_paid: newAmountPaid,
          is_fulfilled: isFulfilled,
          updated_at: new Date().toISOString(),
        })
        .eq('id', pledgeId)
        .eq('church_id', churchId)
        .select()
        .single();
    if (updateError) throw new Error(updateError.message);
    return { payment, pledge: updatedPledge };
  }

  deletePledgePayment(paymentId: string, pledgeId: string): Observable<void> {
    return from(this.removePledgePayment(paymentId, pledgeId));
  }

  private async removePledgePayment(
    paymentId: string,
    pledgeId: string,
  ): Promise<void> {
    const churchId = this.getChurchId();
    const { data: payment, error: fetchError } = await this.supabase.client
      .from('pledge_payments')
      .select('amount')
      .eq('id', paymentId)
      .eq('church_id', churchId)
      .single();
    if (fetchError) throw new Error(fetchError.message);

    const { error: deleteError } = await this.supabase.client
      .from('pledge_payments')
      .delete()
      .eq('id', paymentId)
      .eq('church_id', churchId);
    if (deleteError) throw new Error(deleteError.message);

    const { data: pledge, error: pledgeError } = await this.supabase.client
      .from('pledges')
      .select('amount_paid, pledge_amount')
      .eq('id', pledgeId)
      .eq('church_id', churchId)
      .single();
    if (pledgeError) throw new Error(pledgeError.message);

    const newAmountPaid = Math.max(0, pledge.amount_paid - payment.amount);
    const isFulfilled = newAmountPaid >= pledge.pledge_amount;
    await this.supabase.client
      .from('pledges')
      .update({
        amount_paid: newAmountPaid,
        is_fulfilled: isFulfilled,
        updated_at: new Date().toISOString(),
      })
      .eq('id', pledgeId)
      .eq('church_id', churchId);
  }

  // ==================== STATISTICS & REPORTS ====================

  getGivingStatistics(fiscalYear?: number): Observable<GivingStatistics> {
    const churchId = this.getChurchId();
    const isBranchPastor = this.isBranchPastor();
    const branchId = this.getBranchId();
    const year = fiscalYear || new Date().getFullYear();

    if (isBranchPastor && branchId)
      return from(this.fetchBranchGivingStats(churchId, branchId, year));

    return from(
      this.supabase.client.rpc('get_giving_stats', {
        church_uuid: churchId,
        fiscal_year: year,
      }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        if (Array.isArray(data) && data.length > 0)
          return data[0] as GivingStatistics;
        return data as GivingStatistics;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  private async fetchBranchGivingStats(
    churchId: string,
    branchId: string,
    year: number,
  ): Promise<GivingStatistics> {
    const { data } = await this.supabase.client
      .from('giving_transactions')
      .select('amount, category_id')
      .eq('church_id', churchId)
      .eq('branch_id', branchId)
      .eq('fiscal_year', year);
    const transactions = data || [];
    const amounts = transactions.map((t) => t.amount);
    const total = amounts.reduce((sum, a) => sum + a, 0);
    return {
      total_giving: total,
      total_tithes: 0,
      total_offerings: 0,
      total_transactions: transactions.length,
      avg_giving: transactions.length ? total / transactions.length : 0,
      highest_giving: amounts.length ? Math.max(...amounts) : 0,
    };
  }

  getGivingTrends(monthsBack: number = 12): Observable<GivingTrend[]> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client.rpc('get_giving_trends', {
        church_uuid: churchId,
        months_back: monthsBack,
      }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return (data || []) as GivingTrend[];
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  getTopGivers(
    limit: number = 10,
    fiscalYear?: number,
  ): Observable<TopGiver[]> {
    const churchId = this.getChurchId();
    const year = fiscalYear || new Date().getFullYear();
    return from(
      this.supabase.client.rpc('get_top_givers', {
        church_uuid: churchId,
        fiscal_year: year,
        result_limit: limit,
      }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return (data || []) as TopGiver[];
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  getMemberGivingHistory(
    memberId: string,
    fiscalYear?: number,
  ): Observable<any> {
    const year = fiscalYear || new Date().getFullYear();
    return from(
      this.supabase.client.rpc('get_member_giving_summary', {
        member_uuid: memberId,
        fiscal_year: year,
      }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  // ==================== EXPORTS ====================

  exportGivingReport(
    startDate: string,
    endDate: string,
    categoryId?: string,
  ): Observable<Blob> {
    return this.getGivingTransactions(1, 10000, {
      startDate,
      endDate,
      categoryId,
    }).pipe(
      map(({ data }) => {
        const headers = [
          'Date',
          'Member',
          'Member Number',
          'Category',
          'Amount',
          'Currency',
          'Payment Method',
          'Reference',
          'Notes',
        ];
        const rows = data.map((t: any) => [
          t.transaction_date,
          t.member
            ? `${t.member.first_name} ${t.member.last_name}`
            : 'Anonymous',
          t.member?.member_number || 'N/A',
          t.category?.name || 'General',
          t.amount,
          t.currency,
          t.payment_method,
          t.transaction_reference || '',
          t.notes || '',
        ]);
        const csv = [
          headers.join(','),
          ...rows.map((row) => row.map((cell) => `"${cell}"`).join(',')),
        ].join('\n');
        return new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      }),
    );
  }

  exportPledgesReport(): Observable<Blob> {
    return this.getPledges(1, 10000).pipe(
      map(({ data }) => {
        const headers = [
          'Member',
          'Category',
          'Pledge Amount',
          'Amount Paid',
          'Balance',
          'Currency',
          'Pledge Date',
          'Due Date',
          'Status',
        ];
        const rows = data.map((pledge: any) => {
          const pledgerName = pledge.member
            ? `${pledge.member.first_name} ${pledge.member.last_name}`
            : `${pledge.visitor_first_name || ''} ${pledge.visitor_last_name || ''}`.trim() ||
              'Visitor';
          const balance = pledge.pledge_amount - pledge.amount_paid;
          return [
            pledgerName,
            pledge.category?.name || 'General',
            pledge.pledge_amount,
            pledge.amount_paid,
            balance,
            pledge.currency,
            pledge.pledge_date,
            pledge.due_date || 'N/A',
            pledge.is_fulfilled ? 'Fulfilled' : 'Pending',
          ];
        });
        const csv = [
          headers.join(','),
          ...rows.map((row) => row.map((cell) => `"${cell}"`).join(',')),
        ].join('\n');
        return new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      }),
    );
  }

  getMonthlyGivingData(year: number): Observable<any[]> {
    const churchId = this.getChurchId();
    return from(
      this.supabase.client
        .from('monthly_giving_summary')
        .select('*')
        .eq('church_id', churchId)
        .eq('year', year)
        .order('month', { ascending: true }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data || [];
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  getCategoryGivingStats(
    fiscalYear?: number,
    startDate?: string,
    endDate?: string,
  ): Observable<CategoryGivingStat[]> {
    return from(this.fetchCategoryStats(fiscalYear, startDate, endDate));
  }

  getCategoryGivers(
    categoryId: string,
    fiscalYear?: number,
    startDate?: string,
    endDate?: string,
    limit: number = 50,
  ): Observable<CategoryGiver[]> {
    return from(
      this.fetchCategoryGivers(
        categoryId,
        fiscalYear,
        startDate,
        endDate,
        limit,
      ),
    );
  }

  private async fetchCategoryStats(
    fiscalYear?: number,
    startDate?: string,
    endDate?: string,
  ): Promise<CategoryGivingStat[]> {
    const churchId = this.getChurchId();
    const { data, error } = await this.supabase.client.rpc(
      'get_category_giving_stats',
      {
        church_uuid: churchId,
        p_fiscal_year: fiscalYear ?? null,
        p_start_date: startDate ?? null,
        p_end_date: endDate ?? null,
      },
    );
    if (error) throw new Error(error.message);
    return (data || []) as CategoryGivingStat[];
  }

  private async fetchCategoryGivers(
    categoryId: string,
    fiscalYear?: number,
    startDate?: string,
    endDate?: string,
    limit: number = 50,
  ): Promise<CategoryGiver[]> {
    const churchId = this.getChurchId();
    const { data, error } = await this.supabase.client.rpc(
      'get_category_givers',
      {
        church_uuid: churchId,
        category_uuid: categoryId,
        p_fiscal_year: fiscalYear ?? null,
        p_start_date: startDate ?? null,
        p_end_date: endDate ?? null,
        result_limit: limit,
      },
    );
    if (error) throw new Error(error.message);
    return (data || []) as CategoryGiver[];
  }

  getPaystackBalance(): Observable<{
    confirmed_balance: number;
    pending_balance: number;
    transaction_count: number;
  }> {
    let churchId: string;
    try {
      churchId = this.getChurchId();
    } catch {
      return of({
        confirmed_balance: 0,
        pending_balance: 0,
        transaction_count: 0,
      });
    }

    return from(
      this.supabase.client.rpc('get_paystack_balance', {
        church_uuid: churchId,
      }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data as {
          confirmed_balance: number;
          pending_balance: number;
          transaction_count: number;
        };
      }),
      catchError(() =>
        of({ confirmed_balance: 0, pending_balance: 0, transaction_count: 0 }),
      ),
    );
  }

  // Sums completed withdrawals for this church — used to show admins how
  // much of their confirmed Paystack balance has already been paid out
  // vs. how much is still actually available to withdraw. Without this,
  // the "Paystack Collected" figure alone can look like unclaimed money
  // is still sitting there even after a successful withdrawal.
  getWithdrawnTotal(): Observable<number> {
    let churchId: string;
    try {
      churchId = this.getChurchId();
    } catch {
      return of(0);
    }

    return from(
      this.supabase.client
        .from('withdrawal_requests')
        .select('amount')
        .eq('church_id', churchId)
        .eq('status', 'completed'),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return (data || []).reduce((sum: number, r: any) => sum + Number(r.amount), 0);
      }),
      catchError(() => of(0)),
    );
  }

  getGivingTransactionsFiltered(
    page: number,
    pageSize: number,
    filters?: {
      startDate?: string;
      endDate?: string;
      categoryId?: string;
      paymentMethod?: string;
      paystackOnly?: boolean;
    },
  ): Observable<{ data: any[]; count: number }> {
    // reuse existing getGivingTransactions but paystackOnly forces paymentMethod = 'paystack'
    const resolvedFilters: {
      startDate?: string;
      endDate?: string;
      categoryId?: string;
      paymentMethod?: PaymentMethod | '';
    } = {
      ...filters,
      paymentMethod: filters?.paystackOnly
        ? ('paystack' as PaymentMethod)
        : (filters?.paymentMethod as PaymentMethod | ''),
    };

    return this.getGivingTransactions(page, pageSize, resolvedFilters);
  }
}
