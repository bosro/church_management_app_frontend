// src/app/features/ministries/components/create-ministry/create-ministry.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { MinistryService } from '../../../services/ministry.service';
import { DAYS_OF_WEEK } from '../../../../../models/ministry.model';
import { PermissionService } from '../../../../../core/services/permission.service';
import { AuthService } from '../../../../../core/services/auth';

@Component({
  selector: 'app-create-ministry',
  standalone: false,
  templateUrl: './create-ministry.html',
  styleUrl: './create-ministry.scss',
})
export class CreateMinistry implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();

  ministryForm!: FormGroup;
  loading = false;
  errorMessage = '';
  successMessage = '';

  daysOfWeek = DAYS_OF_WEEK;

  // Permissions
  canManageMinistries = false;

  constructor(
    private fb: FormBuilder,
    private ministryService: MinistryService,
    private router: Router,
    public permissionService: PermissionService,
    private authService: AuthService,
  ) {}

  ngOnInit(): void {
    this.checkPermissions();
    this.initForm();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private checkPermissions(): void {
    const role = this.authService.getCurrentUserRole();

    const manageRoles = [
      'pastor',
      'senior_pastor',
      'associate_pastor',
      'ministry_leader',
    ];

    this.canManageMinistries =
      this.permissionService.isAdmin ||
      this.permissionService.ministries.manage ||
      manageRoles.includes(role);

    if (!this.canManageMinistries) {
      this.router.navigate(['/unauthorized']);
    }
  }

  private initForm(): void {
    this.ministryForm = this.fb.group({
      name: [
        '',
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(100),
        ],
      ],
      description: ['', [Validators.maxLength(500)]],
      meeting_day: [''],
      meeting_time: [
        '',
        [Validators.pattern(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/)],
      ],
      meeting_location: ['', [Validators.maxLength(200)]],
    });
  }

  // CHARACTER COUNTER GETTER - ADDED
  get descriptionLength(): number {
    const descriptionControl = this.ministryForm?.get('description');
    if (!descriptionControl) {
      return 0;
    }
    const value = descriptionControl.value;
    return value ? value.length : 0;
  }

  // Helper method to check if field is invalid - ADDED
  isFieldInvalid(fieldName: string): boolean {
    const control = this.ministryForm.get(fieldName);
    return !!(control && control.invalid && control.touched);
  }

  onSubmit(): void {
    // Mark all fields as touched to show validation errors
    this.markFormGroupTouched(this.ministryForm);

    if (this.ministryForm.invalid) {
      this.errorMessage = 'Please fill in all required fields correctly';

      // Show specific error for description length
      const descControl = this.ministryForm.get('description');
      if (descControl?.hasError('maxlength')) {
        this.errorMessage =
          'Description is too long. Maximum 500 characters allowed.';
      }

      setTimeout(() => {
        this.scrollToFirstInvalidField();
      }, 100);

      return;
    }

    this.loading = true;
    this.errorMessage = '';
    this.successMessage = '';

    const ministryData = this.ministryForm.value;

    this.ministryService
      .createMinistry(ministryData)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (ministry) => {
          this.successMessage = 'Ministry created successfully!';
          this.loading = false;

          setTimeout(() => {
            this.router.navigate(['main/ministries', ministry.id]);
          }, 1500);
        },
        error: (error) => {
          this.loading = false;
          this.errorMessage =
            error.message || 'Failed to create ministry. Please try again.';
          this.scrollToTop();
          console.error('Create ministry error:', error);
        },
      });
  }

  cancel(): void {
    if (this.ministryForm.dirty) {
      if (
        confirm('You have unsaved changes. Are you sure you want to leave?')
      ) {
        this.router.navigate(['main/ministries']);
      }
    } else {
      this.router.navigate(['main/ministries']);
    }
  }

  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((key) => {
      const control = formGroup.get(key);
      control?.markAsTouched();

      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  getErrorMessage(fieldName: string): string {
    const control = this.ministryForm.get(fieldName);

    if (!control || !control.errors || !control.touched) {
      return '';
    }

    if (control.hasError('required')) {
      return 'This field is required';
    }
    if (control.hasError('minlength')) {
      const minLength = control.getError('minlength').requiredLength;
      return `Minimum ${minLength} characters required`;
    }
    if (control.hasError('maxlength')) {
      const maxLength = control.getError('maxlength').requiredLength;
      return `Maximum ${maxLength} characters allowed`;
    }
    if (control.hasError('pattern')) {
      if (fieldName === 'meeting_time') {
        return 'Invalid time format. Use HH:MM (e.g., 14:30)';
      }
    }

    return 'Invalid input';
  }

  private scrollToFirstInvalidField(): void {
    // Find first invalid field with error class
    const firstInvalidControl: HTMLElement | null = document.querySelector(
      'input.error, textarea.error, select.error',
    );

    if (firstInvalidControl) {
      firstInvalidControl.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
      });

      // Focus after scroll completes
      setTimeout(() => {
        firstInvalidControl.focus();
      }, 400);
    }
  }

  private scrollToTop(): void {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}
