import { Injectable } from '@angular/core';
import { Observable, from, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Church } from '../../../models/church.model';
import { SignupRequest, User } from '../../../models/user.model';
import { SupabaseService } from '../../../core/services/supabase';

export interface UserWithChurch extends User {
  church?: Church;
}

export interface ApprovalStats {
  total_pending: number;
  total_approved: number;
  total_rejected: number;
  pending_this_week: number;
}

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  constructor(private supabase: SupabaseService) {}

  /**
   * Get all users (super admin only)
   */
  getAllUsers(): Observable<UserWithChurch[]> {
    return from(
      this.supabase.client
        .from('profiles')
        .select(
          `
          *,
          church:churches(*)
        `,
        )
        .order('created_at', { ascending: false }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw error;
        return data as UserWithChurch[];
      }),
    );
  }

  /**
   * Get all churches (super admin only)
   */
  getAllChurches(): Observable<Church[]> {
    return from(
      this.supabase.client
        .from('churches')
        .select('*')
        .order('created_at', { ascending: false }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw error;
        return data as Church[];
      }),
    );
  }

  /**
   * Get pending signup requests
   */
  getPendingSignupRequests(): Observable<SignupRequest[]> {
    return from(
      this.supabase.client
        .from('signup_requests')
        .select('*')
        .eq('status', 'pending')
        .order('created_at', { ascending: false }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw error;
        return data as SignupRequest[];
      }),
    );
  }

  /**
   * Get all signup requests (with filters)
   */
  getSignupRequests(status?: string): Observable<SignupRequest[]> {
    let query = this.supabase.client
      .from('signup_requests')
      .select('*')
      .order('created_at', { ascending: false });

    if (status) {
      query = query.eq('status', status);
    }

    return from(query).pipe(
      map(({ data, error }) => {
        if (error) throw error;
        return data as SignupRequest[];
      }),
    );
  }

  /**
   * Approve signup request
   */
  approveSignupRequest(
    requestId: string,
    churchId?: string,
    adminId?: string,
  ): Observable<any> {
    return from(
      this.supabase.callFunction('approve_signup_request', {
        p_request_id: requestId,
        p_admin_id: adminId,
        p_church_id: churchId || null,
      }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw error;
        return data;
      }),
    );
  }

  /**
   * Reject signup request
   */
  rejectSignupRequest(
    requestId: string,
    reason: string,
    adminId?: string,
  ): Observable<any> {
    return from(
      this.supabase.callFunction('reject_signup_request', {
        p_request_id: requestId,
        p_admin_id: adminId,
        p_reason: reason || null,
      }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw error;
        return data;
      }),
    );
  }

  /**
   * Toggle user active status
   */
  toggleUserStatus(userId: string, isActive: boolean): Observable<any> {
    return from(
      this.supabase.update('profiles', userId, { is_active: isActive }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw error;
        return data;
      }),
    );
  }

  /**
   * Update user role
   */
  updateUserRole(userId: string, role: string): Observable<any> {
    return from(
      Promise.all([
        this.supabase.update('profiles', userId, { role }),
        this.supabase.client
          .from('users')
          .update({ role, updated_at: new Date().toISOString() })
          .eq('id', userId),
      ]),
    ).pipe(
      map(([profilesResult, usersResult]) => {
        if (profilesResult.error) throw profilesResult.error;
        if (usersResult.error) throw usersResult.error;
        return profilesResult.data;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  /**
   * Get approval statistics
   */
  getApprovalStats(): Observable<ApprovalStats> {
    return from(
      this.supabase.client.from('signup_requests').select('status, created_at'),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw error;

        const requests = data || [];
        const oneWeekAgo = new Date();
        oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

        return {
          total_pending: requests.filter((r) => r.status === 'pending').length,
          total_approved: requests.filter((r) => r.status === 'approved')
            .length,
          total_rejected: requests.filter((r) => r.status === 'rejected')
            .length,
          pending_this_week: requests.filter(
            (r) =>
              r.status === 'pending' && new Date(r.created_at) >= oneWeekAgo,
          ).length,
        };
      }),
    );
  }

  /**
   * Create new church
   */
  createChurch(churchData: Partial<Church>): Observable<Church> {
    return from(this.supabase.insert('churches', churchData)).pipe(
      map(({ data, error }) => {
        if (error) throw error;
        return data?.[0] as Church;
      }),
    );
  }

  /**
   * Update user church assignment
   */
  updateUserChurch(userId: string, churchId: string | null): Observable<any> {
    return from(
      Promise.all([
        this.supabase.update('profiles', userId, { church_id: churchId }),
        this.supabase.client
          .from('users')
          .update({ church_id: churchId, updated_at: new Date().toISOString() })
          .eq('id', userId),
      ]),
    ).pipe(
      map(([profilesResult, usersResult]) => {
        if (profilesResult.error) throw profilesResult.error;
        if (usersResult.error) throw usersResult.error;
        return profilesResult.data;
      }),
      catchError((err) => throwError(() => err)),
    );
  }

  /**
   * Update church
   */
  updateChurch(
    churchId: string,
    churchData: Partial<Church>,
  ): Observable<Church> {
    return from(this.supabase.update('churches', churchId, churchData)).pipe(
      map(({ data, error }) => {
        if (error) throw error;
        return data?.[0] as Church;
      }),
    );
  }

  /**
   * Delete church (soft delete by setting is_active = false)
   */
  deleteChurch(churchId: string): Observable<any> {
    return this.setChurchActive(churchId, false);
  }

  /**
   * Deactivate or reactivate a church (super admin only).
   * Deactivating hides it from signup, blocks its users and signs them out.
   */
  setChurchActive(churchId: string, active: boolean): Observable<any> {
    return from(
      this.supabase.client.rpc('admin_set_church_active', {
        p_church_id: churchId,
        p_active: active,
      }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data;
      }),
    );
  }

  clearUserPermissions(userId: string): Observable<void> {
    return from(
      this.supabase.client
        .from('user_permissions')
        .delete()
        .eq('user_id', userId),
    ).pipe(
      map(({ error }) => {
        if (error) throw error;
      }),
    );
  }

  /**
   * Get all churches with subscription info and usage
   */
  getAllChurchesWithSubscription(): Observable<any[]> {
    return from(
      this.supabase.client
        .from('churches')
        .select(
          `
      id, name, location, is_active, created_at,
      subscription_plan, subscription_tier,
      subscription_expires_at, subscription_started_at,
      billing_email, payment_reference,
      contact_email, contact_phone, size_category,
      enabled_features, is_complimentary, billing_cycle
    `,
        )
        .order('created_at', { ascending: false }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw error;
        return data || [];
      }),
    );
  }

  /**
   * Update church subscription (super admin only) — manual grants / bank or MoMo payments.
   * Plan features now come from subscription_plans.plan_features (no more hard-coded list).
   * `complimentary` = never auto-downgraded and no reminder emails (use for free grants / partners).
   */
  updateChurchSubscription(
    churchId: string,
    planId: string,
    durationMonths: number,
    paymentReference: string,
    billingEmail?: string,
    complimentary: boolean = false,
  ): Observable<void> {
    const months = Number(durationMonths) || 1;
    const expiresAt = new Date();
    expiresAt.setMonth(expiresAt.getMonth() + months);

    return from(
      (async () => {
        const [{ data: plans }, { data: current }] = await Promise.all([
          this.supabase.client.from('subscription_plans').select('id, plan_features'),
          this.supabase.client
            .from('churches')
            .select('enabled_features, subscription_plan')
            .eq('id', churchId)
            .maybeSingle(),
        ]);

        const managed = new Set<string>();
        (plans || []).forEach((p: any) => (p.plan_features || []).forEach((f: string) => managed.add(f)));
        const planFeatureList: string[] =
          (plans || []).find((p: any) => p.id === planId)?.plan_features || [];
        // manual flags (e.g. branch_autonomy) are never wiped
        const keepManual = (current?.enabled_features || []).filter((f: string) => !managed.has(f));
        const featuresToEnable = Array.from(new Set([...planFeatureList, ...keepManual]));

        const isFree = planId === 'free';
        return this.supabase.client
          .from('churches')
          .update({
            subscription_plan: planId,
            subscription_tier: planId === 'pro' ? 'premium' : planId,
            subscription_expires_at: isFree ? null : expiresAt.toISOString(),
            subscription_started_at: new Date().toISOString(),
            subscription_renewed_at: new Date().toISOString(),
            subscription_cancelled_at: null,
            billing_cycle: isFree ? null : months >= 12 ? 'yearly' : 'monthly',
            is_complimentary: !isFree && complimentary,
            previous_plan:
              current?.subscription_plan && current.subscription_plan !== planId
                ? current.subscription_plan
                : undefined,
            payment_reference: paymentReference || null,
            billing_email: billingEmail || null,
            enabled_features: featuresToEnable,
            updated_at: new Date().toISOString(),
          })
          .eq('id', churchId);
      })(),
    ).pipe(
      map(({ error }) => {
        if (error) throw new Error(error.message);
      }),
    );
  }

  /** One call for the church detail screen: church, plan state, usage, staff, last payments, member totals */
  getChurchSummary(churchId: string): Observable<any> {
    return from(this.supabase.client.rpc('admin_get_church_summary', { p_church_id: churchId })).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data;
      }),
    );
  }

  /** Members of a church (name, email, phone, status…) + total count. Super admin only (RPC checks). */
  getChurchMembers(churchId: string, search = '', limit = 25, offset = 0, branchId: string | null = null): Observable<any> {
    return from(
      this.supabase.client.rpc('admin_get_church_members', {
        p_church_id: churchId,
        p_search: search || null,
        p_limit: limit,
        p_offset: offset,
        p_branch_id: branchId || null,
      }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw new Error(error.message);
        return data;
      }),
    );
  }

  /**
   * Get usage for a specific church
   */
  getChurchUsage(churchId: string): Observable<any> {
    return from(
      this.supabase.client.rpc('get_church_usage', {
        p_church_id: churchId,
      }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw error;
        return data;
      }),
    );
  }

  provisionChurchForUser(
    userId: string,
    churchName: string,
    churchLocation: string = 'Ghana',
    churchSize?: string,
  ): Observable<any> {
    return from(
      this.supabase.client.rpc('provision_church_for_user', {
        p_user_id: userId,
        p_church_name: churchName,
        p_church_location: churchLocation,
        p_church_size: churchSize || null,
        p_admin_id: this.supabase.currentUser?.id,
      }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw error;
        return data;
      }),
    );
  }

  deleteUserCompletely(userId: string): Observable<any> {
    const adminId = this.supabase.currentUser?.id;

    return from(
      this.supabase.client.rpc('delete_user_completely', {
        p_user_id: userId,
        p_admin_id: adminId,
      }),
    ).pipe(
      map(({ data, error }) => {
        if (error) throw error;
        if (data?.success === false) throw new Error(data.message);
        return data;
      }),
      catchError((err) => throwError(() => err)),
    );
  }
}
