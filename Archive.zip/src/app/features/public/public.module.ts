// src/app/features/public/public.module.ts
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { QrCodeModule } from 'ng-qrcode';

import { LinkCheckin } from './link-checkin/link-checkin';
import { MemberRegistration } from './member-registration/member-registration';
import { FeedingRecord } from './feeding-record/feeding-record';
import { PublicStudentRegistration } from './public-student-registration/public-student-registration';
import { PublicEventRegistration } from './event-registration/event-registration';
import { GivingThankYouPage } from './giving-thank-you/giving-thank-you';
import { CommitmentForm } from '../building-campaign/components/commitment-form/commitment-form';
import { BuildingCampaignPaymentCallback } from './building-campaign-payment-callback/building-campaign-payment-callback';

const routes: Routes = [
  {
    path: 'giving/thank-you',
    component: GivingThankYouPage,
    // No canActivate — anyone who paid via a payment link lands here
  },
  {
  path: 'building-campaign/payment-callback',
  component: BuildingCampaignPaymentCallback,
},
  {
    path: 'link-checkin/:token',
    component: LinkCheckin,
  },
  {
    path: 'register/:token',
    component: MemberRegistration,
  },
  {
    path: 'feeding-fees/:churchId', // ← was :token
    component: FeedingRecord,
  },
  {
    path: 'student-register/:token',
    component: PublicStudentRegistration,
  },
  {
    path: 'event-register/:eventId',
    component: PublicEventRegistration,
  },
   {
    path: 'building-campaign/:churchId',
    component: CommitmentForm,
  },
];

@NgModule({
  declarations: [
    LinkCheckin,
    MemberRegistration,
    FeedingRecord,
    PublicStudentRegistration,
    PublicEventRegistration,
    GivingThankYouPage,
    BuildingCampaignPaymentCallback
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    QrCodeModule,
    RouterModule.forChild(routes),
  ],
})
export class PublicModule {}
